# Pattern-Recognition-Projects

#### This repository contains all the projects completed as part of the Pattern Recognition course.
